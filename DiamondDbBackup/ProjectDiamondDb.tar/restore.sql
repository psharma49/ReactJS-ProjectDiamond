--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.18
-- Dumped by pg_dump version 9.6.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.product_master DROP CONSTRAINT product_master_portfolio_id_fkey;
ALTER TABLE ONLY public.product_master DROP CONSTRAINT product_master_lob_id_fkey;
ALTER TABLE ONLY public.portfolio DROP CONSTRAINT portfolio_lob_id_fkey;
ALTER TABLE ONLY public.kpi_subcategory DROP CONSTRAINT kpi_subcategory_kpi_id_fkey1;
ALTER TABLE ONLY public.temp DROP CONSTRAINT kpi_subcategory_kpi_id_fkey;
ALTER TABLE ONLY public.feature DROP CONSTRAINT feature_product_id_fkey1;
ALTER TABLE ONLY public.temp1 DROP CONSTRAINT feature_product_id_fkey;
ALTER TABLE ONLY public.feature DROP CONSTRAINT feature_portfolio_id_fkey1;
ALTER TABLE ONLY public.temp1 DROP CONSTRAINT feature_portfolio_id_fkey;
ALTER TABLE ONLY public.feature DROP CONSTRAINT feature_lob_id_fkey1;
ALTER TABLE ONLY public.temp1 DROP CONSTRAINT feature_lob_id_fkey;
ALTER TABLE ONLY public.feature DROP CONSTRAINT feature_kpi_subcategory_id_fkey1;
ALTER TABLE ONLY public.temp1 DROP CONSTRAINT feature_kpi_subcategory_id_fkey;
ALTER TABLE ONLY public.feature DROP CONSTRAINT feature_kpi_id_fkey1;
ALTER TABLE ONLY public.temp1 DROP CONSTRAINT feature_kpi_id_fkey;
ALTER TABLE ONLY public.year DROP CONSTRAINT year_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.product_master DROP CONSTRAINT product_master_pkey;
ALTER TABLE ONLY public.portfolio DROP CONSTRAINT portfolio_pkey;
ALTER TABLE ONLY public.lob DROP CONSTRAINT lob_pkey;
ALTER TABLE ONLY public.kpi_subcategory DROP CONSTRAINT kpi_subcategory_pkey1;
ALTER TABLE ONLY public.temp DROP CONSTRAINT kpi_subcategory_pkey;
ALTER TABLE ONLY public.kpi_master DROP CONSTRAINT kpi_master_pkey;
ALTER TABLE ONLY public.feature DROP CONSTRAINT feature_pkey1;
ALTER TABLE ONLY public.temp1 DROP CONSTRAINT feature_pkey;
ALTER TABLE public.feature ALTER COLUMN feature_id DROP DEFAULT;
DROP TABLE public.year;
DROP TABLE public.users;
DROP TABLE public.temp1;
DROP TABLE public.temp;
DROP TABLE public.product_master;
DROP TABLE public.portfolio;
DROP TABLE public.lob;
DROP TABLE public.kpi_subcategory;
DROP TABLE public.kpi_master;
DROP SEQUENCE public.feature_feature_id_seq;
DROP TABLE public.feature;
DROP EXTENSION pgcrypto;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: feature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature (
    feature_id integer NOT NULL,
    feature_name character varying(500) NOT NULL,
    feature_month character varying(30),
    ttv numeric,
    velocity numeric,
    project_type character varying(50),
    business_value numeric,
    unit_of_measurement character varying(50),
    kpi_subcategory_id integer,
    kpi_id integer,
    product_id integer,
    portfolio_id integer,
    lob_id integer,
    year integer,
    quarter character varying(50),
    CONSTRAINT check_parameters CHECK (((feature_id > 0) AND (kpi_subcategory_id > 0) AND (kpi_id > 0) AND (product_id > 0) AND (portfolio_id > 0) AND (lob_id > 0)))
);


ALTER TABLE public.feature OWNER TO postgres;

--
-- Name: feature_feature_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.feature_feature_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.feature_feature_id_seq OWNER TO postgres;

--
-- Name: feature_feature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.feature_feature_id_seq OWNED BY public.feature.feature_id;


--
-- Name: kpi_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_master (
    kpi_id integer NOT NULL,
    kpi_name character varying(50) NOT NULL,
    CONSTRAINT check_parameters CHECK ((kpi_id > 0))
);


ALTER TABLE public.kpi_master OWNER TO postgres;

--
-- Name: kpi_subcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kpi_subcategory (
    kpi_subcategory_id integer NOT NULL,
    kpi_subcategory_name character varying(50) NOT NULL,
    project_type character varying(50),
    unit_of_measurement character varying(50),
    value numeric,
    kpi_id integer,
    timeline character varying(100),
    display_name character varying(100),
    display_order integer,
    CONSTRAINT check_parameters CHECK (((kpi_subcategory_id > 0) AND (kpi_id > 0)))
);


ALTER TABLE public.kpi_subcategory OWNER TO postgres;

--
-- Name: lob; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lob (
    lob_id integer NOT NULL,
    lob_name character varying(30) NOT NULL,
    lob_status character(1) NOT NULL,
    CONSTRAINT check_lob CHECK ((lob_id > 0)),
    CONSTRAINT check_lob_status CHECK (((lob_status = 'Y'::bpchar) OR (lob_status = 'N'::bpchar)))
);


ALTER TABLE public.lob OWNER TO postgres;

--
-- Name: portfolio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portfolio (
    portfolio_id integer NOT NULL,
    portfolio_name character varying(50) NOT NULL,
    portfolio_status character(1),
    lob_id integer,
    CONSTRAINT check_parameters CHECK (((portfolio_id > 0) AND ((portfolio_status = 'Y'::bpchar) OR (portfolio_status = 'N'::bpchar)) AND (lob_id > 0)))
);


ALTER TABLE public.portfolio OWNER TO postgres;

--
-- Name: product_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_master (
    product_id integer NOT NULL,
    product_name character varying(50),
    product_status character(1),
    portfolio_id integer,
    lob_id integer,
    CONSTRAINT check_parameters CHECK (((product_id > 0) AND ((product_status = 'Y'::bpchar) OR (product_status = 'N'::bpchar)) AND (lob_id > 0) AND (portfolio_id > 0)))
);


ALTER TABLE public.product_master OWNER TO postgres;

--
-- Name: temp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp (
    kpi_subcategory_id integer NOT NULL,
    kpi_subcategory_name character varying(50) NOT NULL,
    project_type character varying(50),
    unit_of_measurement character varying(50),
    "values" numeric,
    kpi_id integer,
    CONSTRAINT check_parameters CHECK (((kpi_subcategory_id > 0) AND (kpi_id > 0)))
);


ALTER TABLE public.temp OWNER TO postgres;

--
-- Name: temp1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp1 (
    feature_id integer NOT NULL,
    feature_name character varying(600) NOT NULL,
    feature_month character varying(30),
    ttv numeric,
    project_type character varying(50),
    business_value numeric,
    unit_of_measurement character varying(50),
    kpi_subcategory_id integer,
    kpi_id integer,
    product_id integer,
    portfolio_id integer,
    lob_id integer,
    CONSTRAINT check_parameters CHECK (((feature_id > 0) AND (kpi_subcategory_id > 0) AND (kpi_id > 0) AND (product_id > 0) AND (portfolio_id > 0) AND (lob_id > 0)))
);


ALTER TABLE public.temp1 OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    user_name character varying(50) NOT NULL,
    password character varying(2000) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    status character(1),
    CONSTRAINT check_parameters CHECK (((user_id > 0) AND ((status = 'Y'::bpchar) OR (status = 'N'::bpchar))))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: year; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.year (
    year_id integer NOT NULL,
    year_number integer
);


ALTER TABLE public.year OWNER TO postgres;

--
-- Name: feature feature_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature ALTER COLUMN feature_id SET DEFAULT nextval('public.feature_feature_id_seq'::regclass);


--
-- Data for Name: feature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature (feature_id, feature_name, feature_month, ttv, velocity, project_type, business_value, unit_of_measurement, kpi_subcategory_id, kpi_id, product_id, portfolio_id, lob_id, year, quarter) FROM stdin;
\.
COPY public.feature (feature_id, feature_name, feature_month, ttv, velocity, project_type, business_value, unit_of_measurement, kpi_subcategory_id, kpi_id, product_id, portfolio_id, lob_id, year, quarter) FROM '$$PATH$$/2242.dat';

--
-- Name: feature_feature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.feature_feature_id_seq', 229, true);


--
-- Data for Name: kpi_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_master (kpi_id, kpi_name) FROM stdin;
\.
COPY public.kpi_master (kpi_id, kpi_name) FROM '$$PATH$$/2244.dat';

--
-- Data for Name: kpi_subcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kpi_subcategory (kpi_subcategory_id, kpi_subcategory_name, project_type, unit_of_measurement, value, kpi_id, timeline, display_name, display_order) FROM stdin;
\.
COPY public.kpi_subcategory (kpi_subcategory_id, kpi_subcategory_name, project_type, unit_of_measurement, value, kpi_id, timeline, display_name, display_order) FROM '$$PATH$$/2245.dat';

--
-- Data for Name: lob; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lob (lob_id, lob_name, lob_status) FROM stdin;
\.
COPY public.lob (lob_id, lob_name, lob_status) FROM '$$PATH$$/2246.dat';

--
-- Data for Name: portfolio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portfolio (portfolio_id, portfolio_name, portfolio_status, lob_id) FROM stdin;
\.
COPY public.portfolio (portfolio_id, portfolio_name, portfolio_status, lob_id) FROM '$$PATH$$/2247.dat';

--
-- Data for Name: product_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_master (product_id, product_name, product_status, portfolio_id, lob_id) FROM stdin;
\.
COPY public.product_master (product_id, product_name, product_status, portfolio_id, lob_id) FROM '$$PATH$$/2248.dat';

--
-- Data for Name: temp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp (kpi_subcategory_id, kpi_subcategory_name, project_type, unit_of_measurement, "values", kpi_id) FROM stdin;
\.
COPY public.temp (kpi_subcategory_id, kpi_subcategory_name, project_type, unit_of_measurement, "values", kpi_id) FROM '$$PATH$$/2249.dat';

--
-- Data for Name: temp1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp1 (feature_id, feature_name, feature_month, ttv, project_type, business_value, unit_of_measurement, kpi_subcategory_id, kpi_id, product_id, portfolio_id, lob_id) FROM stdin;
\.
COPY public.temp1 (feature_id, feature_name, feature_month, ttv, project_type, business_value, unit_of_measurement, kpi_subcategory_id, kpi_id, product_id, portfolio_id, lob_id) FROM '$$PATH$$/2250.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, user_name, password, first_name, last_name, status) FROM stdin;
\.
COPY public.users (user_id, user_name, password, first_name, last_name, status) FROM '$$PATH$$/2251.dat';

--
-- Data for Name: year; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.year (year_id, year_number) FROM stdin;
\.
COPY public.year (year_id, year_number) FROM '$$PATH$$/2252.dat';

--
-- Name: temp1 feature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp1
    ADD CONSTRAINT feature_pkey PRIMARY KEY (feature_id);


--
-- Name: feature feature_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_pkey1 PRIMARY KEY (feature_id);


--
-- Name: kpi_master kpi_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_master
    ADD CONSTRAINT kpi_master_pkey PRIMARY KEY (kpi_id);


--
-- Name: temp kpi_subcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp
    ADD CONSTRAINT kpi_subcategory_pkey PRIMARY KEY (kpi_subcategory_id);


--
-- Name: kpi_subcategory kpi_subcategory_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_subcategory
    ADD CONSTRAINT kpi_subcategory_pkey1 PRIMARY KEY (kpi_subcategory_id);


--
-- Name: lob lob_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lob
    ADD CONSTRAINT lob_pkey PRIMARY KEY (lob_id);


--
-- Name: portfolio portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_pkey PRIMARY KEY (portfolio_id);


--
-- Name: product_master product_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_master
    ADD CONSTRAINT product_master_pkey PRIMARY KEY (product_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: year year_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.year
    ADD CONSTRAINT year_pkey PRIMARY KEY (year_id);


--
-- Name: temp1 feature_kpi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp1
    ADD CONSTRAINT feature_kpi_id_fkey FOREIGN KEY (kpi_id) REFERENCES public.kpi_master(kpi_id);


--
-- Name: feature feature_kpi_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_kpi_id_fkey1 FOREIGN KEY (kpi_id) REFERENCES public.kpi_master(kpi_id);


--
-- Name: temp1 feature_kpi_subcategory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp1
    ADD CONSTRAINT feature_kpi_subcategory_id_fkey FOREIGN KEY (kpi_subcategory_id) REFERENCES public.temp(kpi_subcategory_id);


--
-- Name: feature feature_kpi_subcategory_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_kpi_subcategory_id_fkey1 FOREIGN KEY (kpi_subcategory_id) REFERENCES public.kpi_subcategory(kpi_subcategory_id);


--
-- Name: temp1 feature_lob_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp1
    ADD CONSTRAINT feature_lob_id_fkey FOREIGN KEY (lob_id) REFERENCES public.lob(lob_id);


--
-- Name: feature feature_lob_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_lob_id_fkey1 FOREIGN KEY (lob_id) REFERENCES public.lob(lob_id);


--
-- Name: temp1 feature_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp1
    ADD CONSTRAINT feature_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- Name: feature feature_portfolio_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_portfolio_id_fkey1 FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id);


--
-- Name: temp1 feature_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp1
    ADD CONSTRAINT feature_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product_master(product_id);


--
-- Name: feature feature_product_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature
    ADD CONSTRAINT feature_product_id_fkey1 FOREIGN KEY (product_id) REFERENCES public.product_master(product_id);


--
-- Name: temp kpi_subcategory_kpi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp
    ADD CONSTRAINT kpi_subcategory_kpi_id_fkey FOREIGN KEY (kpi_id) REFERENCES public.kpi_master(kpi_id) ON DELETE CASCADE;


--
-- Name: kpi_subcategory kpi_subcategory_kpi_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kpi_subcategory
    ADD CONSTRAINT kpi_subcategory_kpi_id_fkey1 FOREIGN KEY (kpi_id) REFERENCES public.kpi_master(kpi_id) ON DELETE CASCADE;


--
-- Name: portfolio portfolio_lob_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portfolio
    ADD CONSTRAINT portfolio_lob_id_fkey FOREIGN KEY (lob_id) REFERENCES public.lob(lob_id) ON DELETE CASCADE;


--
-- Name: product_master product_master_lob_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_master
    ADD CONSTRAINT product_master_lob_id_fkey FOREIGN KEY (lob_id) REFERENCES public.lob(lob_id) ON DELETE CASCADE;


--
-- Name: product_master product_master_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_master
    ADD CONSTRAINT product_master_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES public.portfolio(portfolio_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

